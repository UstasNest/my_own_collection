Single task role 
================

for education purposes.

Role Variables
--------------

| Variable | Description    |
+----------+----------------+
|path      |path of file    |
|content   |content of file |


Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - hosts: localhost
      roles: 
        - single_task_role

License
-------

MIT

Author Information
------------------

Rustam Mulyukov 
